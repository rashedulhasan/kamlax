/**
 * 
 */
package com.misc;

/**
 * @author Rashedul.Hasan.Khan
 * 
 */
public class Calculate {

	public static void main(String[] args) {
		int arr[] = new int[] { 3, 2, 5, 6, 8, 0, 7, 7, 4 };
		addAll(arr);

	}

	public static void addAll(int[] arr) {
		for (int i = 0; i < arr.length; i++) {
			int currLine = i + 1;
			if (currLine == arr.length) {
				break;
			}
			if ((currLine % 2) != 0) {
				// it's an odd line, add all until current position
				showLineAndAggregate(arr, currLine);
				i++;
			}
		}

	}

	public static void showLineAndAggregate(int[] arr, int currLine) {
		int currTot = 0;
		System.out.print("Line#" + currLine + " ");
		for (int j = 0; j <= currLine; j++) {
			currTot += arr[j];
			System.out.print(arr[j] + (j == currLine ? "=" : "+"));
		}
		System.out.println(currTot);
	}

}
